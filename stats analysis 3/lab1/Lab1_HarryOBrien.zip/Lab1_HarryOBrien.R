# necessary libraries
library(stringi)

# vectors of animals & animal facts
animals = c("dogs", "cats", "fish")
dogs = c("are brilliant", "are full of love")
cats = c("are evil", "are incredibly selfish")
fish = c("are pretty neutral", "can swim")

idx <- sample( 1:10, size=1, replace=TRUE )

{ 
  If (idx = 1) {
  paste("Did you know", animals[1], dogs[1])
}else if (idx = 2){
  paste("Did you know", animals[1], dogs[2])
}else if (idx = 3){
  paste("Did you know", animals[2], cats[1])
}else if (idx = 4){
  paste("Did you know", animals[2], cats[2])
}else if (idx = 5){
  paste("Did you know", animals[3], fish[1])
}else{
  paste("Did you know", animals[3], fish[2])
}

}
